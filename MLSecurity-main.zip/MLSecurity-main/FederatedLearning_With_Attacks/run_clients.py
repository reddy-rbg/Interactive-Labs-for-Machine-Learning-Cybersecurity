import subprocess
from multiprocessing import Process

def run_client(client_id, is_adversarial=False, dataset="fashionmnist", attack="fgsm", flip_fraction=0.1):
    """
    Function to run each client process by invoking the client.py script.
    :param client_id: The unique ID for the client.
    :param is_adversarial: Boolean flag to indicate if the client is adversarial.
    :param dataset: Dataset to be used by the client (e.g., 'fashionmnist' or 'cifar10').
    :param attack: Adversarial attack type if the client is adversarial (e.g., 'fgsm', 'carliniwagner', 'label_flipping').
    :param flip_fraction: Fraction of labels to flip for adversarial clients.
    """
    cmd = ["python", "client.py", "--client_id", str(client_id), "--num_clients", "10", "--dataset", dataset, "--attack", attack, "--flip_fraction", str(flip_fraction)]
    
    if is_adversarial:
        cmd.append("--is_adversarial")

    subprocess.run(cmd)

if __name__ == "__main__":
    num_clients = 10  # Total number of clients

    adversarial_client_ids = [5, 6, 7, 8]  
    adversarial_attack = "label_flipping"  # You can use 'fgsm', 'carliniwagner', or 'label_flipping'
    dataset = "fashionmnist"
    flip_fraction = 0.2  # Percentage of labels to flip for adversarial clients

    processes = []
    for client_id in range(num_clients):
        is_adversarial = (client_id in adversarial_client_ids)
        attack_type = adversarial_attack if is_adversarial else ""
        p = Process(target=run_client, args=(client_id, is_adversarial, dataset, attack_type, flip_fraction))
        p.start()
        processes.append(p)

    for p in processes:
        p.join()
