# Federated Learning Simulation

This section contains the code to simulate federated learning using multiple clients and a central server.
The server collects model parameters from clients, aggregates them, and sends the updated model back to the clients for further training.

## Files

### 1. `server.py`

This script sets up the federated learning server, which:

- Listens for connections from clients.
- Collects model parameters from each client.
- Aggregates the models by averaging the parameters.
- Sends the updated global model back to all clients after each training round.
- Supports multiple training rounds.

### 2. `client.py`

This script represents a federated learning client. Each client:

- Trains a local model on its own subset of data.
- Can be normal or adversarial (performing attacks like FGSM, Carlini-Wagner, or Label Flipping).
- Sends its trained model to the server.
- Receives the global model from the server and continues training in the next round.

### 3. `run_clients.py`

This script launches multiple client processes simultaneously using Python’s `multiprocessing` module. It can:

- Start normal or adversarial clients.
- Simulate clients training on Fashion-MNIST or CIFAR-10 datasets.
- Configure the number of clients and specify which clients are adversarial.

## Requirements

To run this simulation, you need the following dependencies:

- Python 3.8+
- PyTorch
- CleverHans (for adversarial attacks)
- torchvision (for datasets like Fashion-MNIST and CIFAR-10)

### Install the dependencies:

```bash
pip install torch torchvision cleverhans
```

### How to Run the Simulation

## 1. Run the Server

Start the server first, which will wait for connections from clients.

```bash
python server.py
```

- The server will listen on localhost at port 5001 (you can change the host and port if needed).
- The server will wait for the specified number of clients to connect and perform federated learning over multiple rounds.

## 2. Launch Clients

Once the server is running, you can launch multiple clients using the multiprocess_clients.py script. This will start both normal and adversarial clients concurrently.

```bash
python run_clients.py
```

- This script launches 10 clients by default.
- Clients 5, 6, 7, and 8 are adversarial by default, performing FGSM attacks on their local data.
- You can modify the number of clients, adversarial clients, and dataset in this script.

## Command Line Arguments for client.py

When running clients directly (e.g., in run_clients.py), you can configure them with the following arguments:

- --client_id: The unique ID of the client.
- --num_clients: Total number of clients.
- --dataset: Dataset to be used by the client (fashionmnist or cifar10).
- --attack: Adversarial attack type (fgsm, carliniwagner). Set to an empty string for normal clients.
- --is_adversarial: Set this flag if the client is adversarial.
- --flip_fraction: Fraction of labels to flip for the label_flipping attack (default is 0.1).

## Example:

1. Run a Normal Client (No Adversarial Attack)

```bash
python client.py --client_id 1 --num_clients 10 --dataset fashionmnist --attack ""
```

This will run client 1 as a normal client with no adversarial attack on the Fashion-MNIST dataset.

2. Run a Client with FGSM Attack

```bash
python client.py --client_id 5 --num_clients 10 --dataset fashionmnist --attack fgsm --is_adversarial
```

This will run client 5 as an adversarial client using the FGSM attack on the Fashion-MNIST dataset.

3. Run a Client with Carlini-Wagner Attack

```bash
python client.py --client_id 6 --num_clients 10 --dataset cifar10 --attack carliniwagner --is_adversarial
```

This will run client 6 as an adversarial client using the Carlini-Wagner attack on the CIFAR-10 dataset.

4. Run a Client with Label Flipping Attack

```bash
python client.py --client_id 7 --num_clients 10 --dataset fashionmnist --attack label_flipping --is_adversarial --flip_fraction 0.2
```

This will run client 7 as an adversarial client using the Label Flipping attack on the Fashion-MNIST dataset, flipping 20% of the labels.

5. Run Multiple Clients Simultaneously

```bash
python run_clients.py
```

- By default, clients 5, 6, 7, and 8 will be adversarial.
- You can adjust the attack types and datasets for each client by modifying run_clients.py.
