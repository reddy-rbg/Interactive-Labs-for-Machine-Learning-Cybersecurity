import socket
import threading
import pickle
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader

class Server:
    def __init__(self, host='localhost', port=5000, num_clients=2, num_rounds=5):
        """
        Initialize the server with basic settings.
        :param host: Server address.
        :param port: Server port.
        :param num_clients: Number of clients participating.
        :param num_rounds: Number of federated learning rounds.
        """
        self.host = host
        self.port = port
        self.num_clients = num_clients  # Number of clients
        self.num_rounds = num_rounds  # Number of rounds in federated learning
        self.client_sockets = []  # List of connected client sockets
        self.client_addresses = []  # List of client addresses
        self.model = self.initialize_model()  # Initialize the model (CNN)
        self.lock = threading.Lock()  # Synchronization for thread-safe aggregation
        self.client_data = {}  # Store received model parameters from clients

        # Load test data for evaluating the global model
        self.testloader = self.load_test_data()

    def initialize_model(self):
        """
        Initialize the CNN model architecture.
        :return: CNN model with convolutional layers for Fashion-MNIST.
        """
        model = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),

            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),

            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),

            nn.Flatten(),
            nn.Linear(128 * 3 * 3, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, 10)  # Output layer for 10 classes (Fashion-MNIST)
        )
        return model

    def load_test_data(self):
        """
        Load the Fashion-MNIST test dataset.
        :return: DataLoader for test data.
        """
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))
        ])
        testset = torchvision.datasets.FashionMNIST(root='./data', train=False, download=True, transform=transform)
        testloader = DataLoader(testset, batch_size=32, shuffle=False, num_workers=2)
        return testloader

    def test_model(self):
        """
        Test the model accuracy and loss using test data.
        """
        self.model.eval()  # Set the model to evaluation mode
        correct = 0
        total = 0
        criterion = nn.CrossEntropyLoss()
        test_loss = 0

        # Disable gradient calculation during evaluation
        with torch.no_grad():
            for inputs, labels in self.testloader:
                inputs, labels = inputs.to('cpu'), labels.to('cpu')
                outputs = self.model(inputs)
                loss = criterion(outputs, labels)
                test_loss += loss.item() * inputs.size(0)
                _, predicted = torch.max(outputs, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        accuracy = 100 * correct / total
        test_loss = test_loss / total
        print(f'Test Accuracy: {accuracy:.2f}% | Test Loss: {test_loss:.4f}')

    def start(self):
        """
        Start the server to handle client connections and run federated learning rounds.
        """
        print("Starting server...")
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.bind((self.host, self.port))
        server_sock.listen()
        print(f"Server listening on {self.host}:{self.port}")

        # Accept connections from clients until num_clients are connected
        while len(self.client_sockets) < self.num_clients:
            client_sock, addr = server_sock.accept()
            print(f"Client connected from {addr}")
            self.client_sockets.append(client_sock)
            self.client_addresses.append(addr)

            # Receive adversarial information from the client
            adversarial_info = client_sock.recv(1024).decode('utf-8')
            client_id, is_adversarial, attack_method = adversarial_info.split(',')
            is_adversarial = is_adversarial == 'True'

            # Log if the client is adversarial and what attack method it is using
            attack_method = attack_method if attack_method else "no attack"
            print(f"Client {client_id} is {'Adversarial' if is_adversarial else 'Non-Adversarial'} and is using {attack_method}")

        # Perform federated learning for the specified number of rounds
        for round_num in range(self.num_rounds):
            print(f"\nServer: Starting Round {round_num+1}")
            self.collect_client_models()  # Collect model parameters from clients
            self.aggregate_models()  # Aggregate the models

            # Evaluate the global model after each round
            print(f"Server: Evaluating global model after Round {round_num+1}")
            self.test_model()

            # Send the updated global model back to all clients
            self.send_global_model()
            print(f"Server: Round {round_num+1} completed. Global model sent to all clients.")

        print("Training completed.")

        # Close client sockets after all rounds are completed
        for client_sock in self.client_sockets:
            client_sock.close()

        server_sock.close()

    # Function to collect models from connected clients
    def collect_client_models(self):
        """
        Receive model parameters from each client and store them.
        """
        self.client_data = {}  # Clear client data before collecting for the current round
        for client_sock, addr in zip(self.client_sockets, self.client_addresses):
            print(f"Receiving model parameters from client {addr}")
            data_length = client_sock.recv(16)  # First receive the length of the data
            data_length = int(data_length.decode('utf-8').strip())
            data = b""
            received = 0

            # Receive the serialized model parameters
            while received < data_length:
                packet = client_sock.recv(4096)
                if not packet:
                    break
                data += packet
                received += len(packet)

            client_model_params = pickle.loads(data)  # Deserialize the model parameters
            self.client_data[addr] = client_model_params  # Store model parameters
            print(f"Model parameters received from client {addr}")

    def aggregate_models(self):
        """
        Aggregate the model parameters from all clients by averaging them.
        """
        with self.lock:  # Ensure thread-safe aggregation
            print("Aggregating model parameters...")
            model_params_list = [params for params in self.client_data.values()]

            # Average parameters across all clients
            averaged_params = {}
            for key in model_params_list[0].keys():
                averaged_params[key] = sum([params[key] for params in model_params_list]) / len(model_params_list)

            # Load the aggregated parameters into the global model
            self.model.load_state_dict(averaged_params)
            print("Model parameters aggregated.")

    def send_global_model(self):
        """
        Send the updated global model parameters to all clients.
        """
        print("Sending updated global model to clients.")
        global_model_params = self.model.state_dict()  # Get the global model parameters
        serialized_params = pickle.dumps(global_model_params)  # Serialize model parameters
        data_length = len(serialized_params)
        data_length_str = str(data_length).encode('utf-8').ljust(16)

        # Send the serialized model to each client
        for client_sock in self.client_sockets:
            client_sock.sendall(data_length_str)  # Send the length of the serialized data
            client_sock.sendall(serialized_params)  # Send the serialized model parameters

        print("Global model sent to all clients.")

# Start the server when the script is run
if __name__ == "__main__":
    server = Server(host='localhost', port=5001, num_clients=10, num_rounds=5)
    server.start()
