import socket
import pickle
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from cleverhans.torch.attacks.fast_gradient_method import fast_gradient_method
from cleverhans.torch.attacks.carlini_wagner_l2 import carlini_wagner_l2
import numpy as np

class Client:
    def __init__(self, host='localhost', port=5000, num_rounds=5, client_id=0, num_clients=3, is_adversarial=False, dataset="fashionmnist", attack="fgsm", flip_fraction=0.1):
        """
        Initialize the client with basic settings.
        :param host: Address of the server.
        :param port: Port on which server is listening.
        :param num_rounds: Number of federated learning rounds.
        :param client_id: ID of the client.
        :param num_clients: Total number of clients in the system.
        :param is_adversarial: Boolean to indicate if this is an adversarial client.
        :param dataset: Dataset to use ("fashionmnist" or "cifar10").
        :param attack: Type of adversarial attack ("fgsm", "carliniwagner", or "label_flipping").
        :param flip_fraction: Fraction of labels to flip in case of label flipping attack.
        """
        self.host = host
        self.port = port
        self.num_rounds = num_rounds
        self.client_id = client_id
        self.num_clients = num_clients
        self.is_adversarial = is_adversarial  # Adversarial flag
        self.dataset = dataset.lower()  # Dataset choice
        self.attack = attack.lower()    # Adversarial attack type
        self.flip_fraction = flip_fraction  # Fraction of labels to flip (for label flipping attack)
        self.model = self.initialize_model()  # Initialize the CNN model
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')  # Use GPU if available
        self.model.to(self.device)
        self.trainloader = self.load_data()  # Load the dataset
        self.criterion = nn.CrossEntropyLoss()  # Loss function for training
        self.optimizer = optim.SGD(self.model.parameters(), lr=0.01, momentum=0.9)  # Optimizer

    def initialize_model(self):
        """
        Initialize the CNN model. Adjust the input channels based on the dataset.
        :return: A CNN model based on the dataset.
        """
        if self.dataset == "fashionmnist":
            input_channels = 1  # Fashion-MNIST uses grayscale images
        else:
            input_channels = 3  # CIFAR-10 uses RGB images

        # CNN model architecture
        model = nn.Sequential(
            nn.Conv2d(input_channels, 32, kernel_size=3, padding=1),  # Convolution layer 1
            nn.BatchNorm2d(32),                                       # Batch normalization
            nn.ReLU(),
            nn.MaxPool2d(2, 2),                                       # Pooling layer 1

            nn.Conv2d(32, 64, kernel_size=3, padding=1),              # Convolution layer 2
            nn.BatchNorm2d(64),                                       # Batch normalization
            nn.ReLU(),
            nn.MaxPool2d(2, 2),                                       # Pooling layer 2

            nn.Conv2d(64, 128, kernel_size=3, padding=1),             # Convolution layer 3
            nn.BatchNorm2d(128),                                      # Batch normalization
            nn.ReLU(),
            nn.MaxPool2d(2, 2),                                       # Pooling layer 3

            nn.Flatten(),                                             # Flatten to 1D vector

            nn.Linear(128 * 3 * 3, 256),                              # Fully connected layer 1
            nn.ReLU(),
            nn.Dropout(0.5),                                          # Dropout for regularization

            nn.Linear(256, 128),                                      # Fully connected layer 2
            nn.ReLU(),
            nn.Dropout(0.5),                                          # Dropout for regularization

            nn.Linear(128, 10)                                        # Output layer for 10 classes
        )
        return model

    def load_data(self):
        """
        Load and prepare the dataset for training. Each client gets a subset of the data.
        :return: DataLoader for the client's subset of the dataset.
        """
        if self.dataset == "fashionmnist":
            # Load Fashion-MNIST with normalization
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])
            trainset = torchvision.datasets.FashionMNIST(root='./data', train=True, download=True, transform=transform)
        elif self.dataset == "cifar10":
            # Load CIFAR-10 with normalization
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
        else:
            raise ValueError("Unsupported dataset. Choose between 'fashionmnist' and 'cifar10'.")

        # Split dataset for client
        indices = np.random.permutation(len(trainset))  # Shuffle dataset indices

        # Assign subset of data to the client (e.g., 500 images)
        subset_size = 500
        client_indices = indices[self.client_id * subset_size: (self.client_id + 1) * subset_size]

        print(f"Client {self.client_id}: Assigned dataset indices {self.client_id * subset_size} to {(self.client_id + 1) * subset_size - 1}")

        # Subset the dataset for the client
        client_subset = torch.utils.data.Subset(trainset, client_indices)

        # DataLoader for client's subset
        trainloader = torch.utils.data.DataLoader(client_subset, batch_size=32, shuffle=True, num_workers=2)
        
        return trainloader

    def flip_labels(self, labels, flip_fraction=0.1):
        """
        Flip a fraction of the labels to incorrect labels.
        :param labels: Original labels.
        :param flip_fraction: Fraction of labels to flip.
        :return: Modified labels with some flipped.
        """
        num_labels = len(labels)
        num_flips = int(flip_fraction * num_labels)  # Determine how many labels to flip
        flip_indices = np.random.choice(num_labels, num_flips, replace=False)  # Randomly choose indices to flip

        flipped_labels = labels.clone()  # Clone the labels tensor to modify it
        for idx in flip_indices:
            current_label = labels[idx].item()
            new_label = np.random.choice([i for i in range(10) if i != current_label])  # Randomly choose a different class
            flipped_labels[idx] = new_label

        return flipped_labels

    def adversarial_attack(self, inputs, labels, epsilon=0.1):
        """
        Perform an adversarial attack based on the selected method.
        :param inputs: Original input data.
        :param labels: Corresponding labels for the inputs.
        :param epsilon: Perturbation size for FGSM attack.
        :return: Adversarially modified inputs or flipped labels.
        """
        if self.attack == "fgsm":
            inputs.requires_grad = True
            # Fast Gradient Sign Method (FGSM) attack
            adv_inputs = fast_gradient_method(self.model, inputs, epsilon, norm=np.inf)
            return adv_inputs
        elif self.attack == "carliniwagner":
            # Carlini-Wagner L2 attack (using CleverHans)
            adv_inputs = carlini_wagner_l2(self.model, inputs, 10)
            return adv_inputs
        elif self.attack == "label_flipping":
            # Perform label flipping attack
            flipped_labels = self.flip_labels(labels, self.flip_fraction)
            return inputs, flipped_labels
        else:
            raise ValueError(f"Unsupported attack method: {self.attack}")

    def train(self, epochs=1):
        """
        Train the model locally for a few epochs.
        :param epochs: Number of training epochs.
        """
        self.model.train()  # Set model to training mode
        for epoch in range(epochs):
            for inputs, labels in self.trainloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                
                # Apply adversarial attack if client is adversarial
                if self.is_adversarial:  
                    if self.attack == "label_flipping":
                        inputs, labels = self.adversarial_attack(inputs, labels)
                    else:
                        inputs = self.adversarial_attack(inputs, labels)

                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = self.criterion(outputs, labels)
                loss.backward()
                self.optimizer.step()
        
        print(f"Client {self.client_id}: Training complete for this round. {'(Adversarial)' if self.is_adversarial else '(Normal)'}")

    def connect(self):
        """
        Connect to the server and send information about adversarial status and attack method.
        """
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.host, self.port))
        print(f"Client {self.client_id}: Connected to server.")
        
        # Send a message indicating if the client is adversarial, and the attack method used
        message = f"{self.client_id},{self.is_adversarial},{self.attack}"
        self.sock.sendall(message.encode('utf-8'))

    def send_model(self):
        """
        Send the local model's parameters to the server.
        """
        model_params = self.model.state_dict()
        serialized_params = pickle.dumps(model_params)
        data_length = len(serialized_params)
        self.sock.sendall(str(data_length).encode('utf-8').ljust(16))  # Send the length of the data
        sent = 0
        # Send model parameters in chunks
        while sent < data_length:
            chunk_size = 4096
            self.sock.sendall(serialized_params[sent:sent+chunk_size])
            sent += chunk_size
        print(f"Client {self.client_id}: Model sent to server.")

    def receive_model(self):
        """
        Receive the global model parameters from the server and update the local model.
        """
        data_length = self.sock.recv(16)  # Receive length of incoming data
        data_length = int(data_length.decode('utf-8').strip())
        data = b""
        while len(data) < data_length:
            packet = self.sock.recv(4096)
            if not packet:
                break
            data += packet
        global_model_params = pickle.loads(data)  # Deserialize the model parameters
        self.model.load_state_dict(global_model_params)  # Update local model

    def run(self):
        self.connect()
        for round_num in range(self.num_rounds):
            print(f"\nClient {self.client_id}: Round {round_num+1}")
            self.train(epochs=5)
            self.send_model()
            self.receive_model()
        self.sock.close()
        print(f"Client {self.client_id}: Training completed.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--client_id', type=int, default=0)
    parser.add_argument('--num_clients', type=int, default=3)
    parser.add_argument('--is_adversarial', action='store_true')  # To indicate if this client is adversarial
    parser.add_argument('--dataset', type=str, default='fashionmnist', help="Dataset to use: 'fashionmnist' or 'cifar10'")
    parser.add_argument('--attack', type=str, default='fgsm', help="Attack method: 'fgsm', 'carliniwagner', or 'label_flipping'")
    parser.add_argument('--flip_fraction', type=float, default=0.1, help="Fraction of labels to flip for label flipping attack")  # New argument for label flipping
    args = parser.parse_args()

    client = Client(host='localhost', port=5001, num_rounds=5, client_id=args.client_id, num_clients=args.num_clients, is_adversarial=args.is_adversarial, dataset=args.dataset, attack=args.attack, flip_fraction=args.flip_fraction)
    client.run()
